package me.loda.lazy.anotation;

public class SecondBean {
    public SecondBean() {
        System.out.println("Bean SecondBean đã được khởi tạo!");
    }
}
