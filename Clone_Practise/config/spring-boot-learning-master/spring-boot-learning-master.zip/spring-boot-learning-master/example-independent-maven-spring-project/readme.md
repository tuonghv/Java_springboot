# Source

This is just a example Maven project with Spring Boot Framework

[Loda.me][loda-link]

[loda-link]: https://loda.me

