package me.loda.spring.exampleindependentmavenspringproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleIndependentMavenSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
