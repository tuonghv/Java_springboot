package me.loda.spring.restfulapi;

import lombok.Data;

@Data
public class Todo {
    private String title;
    private String detail;
}
