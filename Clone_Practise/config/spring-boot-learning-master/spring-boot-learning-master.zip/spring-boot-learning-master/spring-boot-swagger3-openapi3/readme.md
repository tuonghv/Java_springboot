# Source
Vào link để xem chi tiết có hình ảnh minh họa:

[Loda.me - RESTful API Document Tạo với Spring Boot + OpenApi 3.0][loda-link]

[loda-link]: https://loda.me/res-tful-api-document-voi-spring-boot-open-api-3-0-loda1576741884390

# Content without images

### Giới thiệu